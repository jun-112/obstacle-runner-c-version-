#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <ctime>
#include "resource.h"


#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "user32.lib")

// Constantes do jogo
const int W = 800, H = 400;
const int groundHeight = 60;
const int groundTop = H - groundHeight;
const int radius = 20;

// coisas 
struct Player {
    float x, y, vy;
    bool onGround;
    int jumps;
};

struct Obstacle {
    float x, y;
    int w, h;
};

struct PowerUp {
    float x, y;
    int w, h;
    std::string type;
};

// Estado Global
HINSTANCE g_hInst = nullptr;
HWND g_hWnd = nullptr;

HDC g_memDC = nullptr;         // backbuffer DC
HBITMAP g_backBmp = nullptr;   // backbuffer
HBITMAP g_oldBmp = nullptr;

HFONT g_font16 = nullptr;
HFONT g_font28b = nullptr;

bool keyDown[256] = { false };  // teclado

// Jogo
Player player;
std::vector<Obstacle> obstacles;
std::vector<PowerUp> powerUps;

float gravity = 0.7f;
float jumpPower = -13.5f;
float baseJumpPower = -13.5f;
float speed = 5.0f;
float speedRamp = 0.0009f;
float multiplier = 1.0f;

int frameCount = 0;
long long score = 0;
long long best = 0;
bool gameOver = false;
bool paused = false;
bool debugMode = false;

int spawnTimer = 0;
int nextSpawnIn = 0;
int minGap = 70;
int maxGap = 140;

int powerUpTimer = 0;
int nextPowerUpIn = 0;
std::string activePowerUp = "";
int powerUpEndFrame = 0;

int fps = 0;
DWORD lastFrameTicks = 0;

DWORD startTicks = 0;   // in�cio da run
double runTime = 0.0; 

typedef BOOL (WINAPI *AlphaBlend_t)(HDC,int,int,int,int,HDC,int,int,int,int,BLENDFUNCTION);
AlphaBlend_t pAlphaBlend = nullptr; // carregado dinamicamente

// =================== Utilit�rios ===================
int randInt(int a, int b) {
    return (rand() % (b - a + 1)) + a;
}

bool chance(float p) { // p em %
    return (rand() / (float)RAND_MAX) * 100.0f < p;
}

bool circleRectCollision(float cx, float cy, float r, float rx, float ry, float rw, float rh) {
    float closestX = std::max(rx, std::min(cx, rx + rw));
    float closestY = std::max(ry, std::min(cy, ry + rh));
    float dx = cx - closestX, dy = cy - closestY;
    return dx * dx + dy * dy <= r * r;
}

std::string formatTime(double seconds) {
    int hrs = (int)(seconds / 3600.0);
    int mins = (int)((int)seconds % 3600 / 60);
    int secs = (int)seconds % 60;
    int ms = (int)((seconds - floor(seconds)) * 1000.0);
    std::ostringstream ss;
    if (hrs > 0) {
        ss << hrs << ":" << std::setw(2) << std::setfill('0') << mins << ":"
           << std::setw(2) << std::setfill('0') << secs << "."
           << std::setw(3) << std::setfill('0') << ms;
    } else if (mins > 0) {
        ss << mins << ":" << std::setw(2) << std::setfill('0') << secs << "."
           << std::setw(3) << std::setfill('0') << ms;
    } else {
        ss << secs << "." << std::setw(3) << std::setfill('0') << ms << "s";
    }
    return ss.str();
}

void resetGame() {
    obstacles.clear();
    powerUps.clear();
    activePowerUp.clear();
    powerUpEndFrame = 0;
    frameCount = 0;
    score = 0;
    multiplier = 1.0f;
    speed = 5.0f;
    jumpPower = baseJumpPower;

    nextSpawnIn = randInt(minGap, maxGap);
    powerUpTimer = 0;
    nextPowerUpIn = randInt(400, 800);

    player.x = 120.0f;
    player.y = (float)(groundTop - radius);
    player.vy = 0.0f;
    player.onGround = true;
    player.jumps = 0;

    gameOver = false;
    paused = false;

    startTicks = GetTickCount();
}

void activatePowerUp(const std::string& type) {
    activePowerUp = type;
    powerUpEndFrame = frameCount + randInt(600, 900);
    if (type == "slow")         speed *= 0.47f;
    if (type == "highJump")     jumpPower = baseJumpPower * 1.5f;
    if (type == "fast")         speed /= 0.5f;
    if (type == "doubleJump")   player.jumps = 0;
    if (type == "doublePoints") multiplier = 2.0f;
    if (type == "triplePoints") multiplier = 3.0f;
    if (type == "quadruplePoints") multiplier = 4.0f;
    if (type == "quintuplePoints") multiplier = 5.0f;
    if (type == "decuplePoints") multiplier = 10.0f;
}

// Input
void onKeyDown(WPARAM vk, LPARAM lParam) {
    if (vk < 256) keyDown[vk] = true;

    // CTRL + I => debug
    if ((GetKeyState(VK_CONTROL) & 0x8000) && vk == 'I') {
        debugMode = !debugMode;
    }

    if (vk == VK_SPACE) {
        if (gameOver) { resetGame(); return; }
        if (player.onGround || (activePowerUp == "doubleJump" && player.jumps < 2)) {
            player.vy = jumpPower;
            player.onGround = false;
            player.jumps++;
        }
    }
    if (vk == 'R') resetGame();
    if (vk == 'P') paused = !paused;

    if (debugMode) {
        if (vk == VK_OEM_6) speed += 1.0f;                 // ']'
        if (vk == VK_OEM_4) speed = std::max(1.0f, speed - 1.0f);// '['
        if (vk == VK_UP)    jumpPower -= 1.0f;
        if (vk == VK_DOWN)  jumpPower += 1.0f;
        if (vk == 'G')      gravity += 0.1f;
        if (vk == 'H')      gravity = std::max(0.1f, gravity - 0.1f);
        if (vk == 'M')      multiplier *= 2.0f;
    }
}

void onKeyUp(WPARAM vk, LPARAM lParam) {
    if (vk < 256) keyDown[vk] = false;
}

// =================== Update (passo fixo 60 FPS) ===================
void updateLogic() {
    if (gameOver || paused) return;

    frameCount++;
    score += (long long)(1.0f * multiplier);
    speed += speedRamp;

    DWORD now = GetTickCount();
    DWORD dtms = now - lastFrameTicks;
    if (dtms == 0) dtms = 1;
    fps = (int)(1000.0f / dtms);
    lastFrameTicks = now;

    if (startTicks) {
        runTime = (now - startTicks) / 1000.0;
    }

    // power-up expira?
    if (!activePowerUp.empty() && frameCount > powerUpEndFrame) {
        if (activePowerUp == "slow")         speed /= 0.47f;
        if (activePowerUp == "highJump")     jumpPower = baseJumpPower;
        if (activePowerUp == "doublePoints") multiplier = 1.0f;
        if (activePowerUp == "triplePoints") multiplier = 1.0f;
        if (activePowerUp == "quadruplePoints") multiplier = 1.0f;
        if (activePowerUp == "quintuplePoints") multiplier = 1.0f;
        if (activePowerUp == "decuplePoints") multiplier = 1.0f;
        if (activePowerUp == "fast")         speed *= 0.5f;
        activePowerUp.clear();
    }

    // f�sica do player
    player.vy += gravity;
    player.y  += player.vy;
    if (player.y > groundTop - radius) {
        player.y = (float)(groundTop - radius);
        player.vy = 0.0f;
        player.onGround = true;
        player.jumps = 0;
    }

    // spawn obst�culo
    spawnTimer++;
    if (spawnTimer >= nextSpawnIn) {
        spawnTimer = 0;
        nextSpawnIn = std::min(nextSpawnIn + randInt(1, 3), maxGap);
        int h = randInt(40, 100);
        int w = randInt(25, 45);
        int y = groundTop - h;
        obstacles.push_back({ (float)W + 10.0f, (float)y, w, h });
    }

    // spawn power-up
    powerUpTimer++;
    if (powerUpTimer >= nextPowerUpIn) {
        powerUpTimer = 0;
        nextPowerUpIn = randInt(400, 800);
        const char* types[] = {"slow","highJump","doubleJump","doublePoints","fast"};
        std::string type = types[randInt(0, 4)];
        if (type == "doublePoints" && chance(8.75f)) type = "triplePoints";
        if (type == "triplePoints" && chance(0.33454f)) type = "quadruplePoints";
        if (type == "quadruplePoints" && chance(0.005f)) type = "quintuplePoints";
        if (type == "quintuplePoints" && chance(0.00000032f)) type = "decuplePoints";
        powerUps.push_back({ (float)W + 10.0f, (float)randInt(100, groundTop - 50), 20, 20, type });
    }

    // mover e checar colis�o
    for (size_t i = 0; i < obstacles.size(); ++i) {
        obstacles[i].x -= speed;
        if (circleRectCollision(player.x, player.y, (float)radius,
                                obstacles[i].x + 5, obstacles[i].y + 5,
                                obstacles[i].w - 10, obstacles[i].h - 10)) {
            gameOver = true;
            best = std::max(best, score);
        }
    }
    for (size_t i = 0; i < powerUps.size();) {
        powerUps[i].x -= speed;
        if (circleRectCollision(player.x, player.y, (float)radius,
                                powerUps[i].x, powerUps[i].y,
                                powerUps[i].w, powerUps[i].h)) {
            activatePowerUp(powerUps[i].type);
            powerUps.erase(powerUps.begin() + i);
        } else {
            ++i;
        }
    }
    // limpar fora da tela
    obstacles.erase(std::remove_if(obstacles.begin(), obstacles.end(),
        [](const Obstacle& o){ return (o.x + o.w) < -50.0f; }), obstacles.end());
    powerUps.erase(std::remove_if(powerUps.begin(), powerUps.end(),
        [](const PowerUp& p){ return (p.x + p.w) < -50.0f; }), powerUps.end());
}

// =================== Render (GDI) ===================
void fillRect(HDC dc, int x, int y, int w, int h, COLORREF color) {
    HBRUSH br = CreateSolidBrush(color);
    RECT rc{ x, y, x + w, y + h };
    FillRect(dc, &rc, br);
    DeleteObject(br);
}

void drawText(HDC dc, int x, int y, const std::string& s, COLORREF color, HFONT font) {
    int oldBk = SetBkMode(dc, TRANSPARENT);
    COLORREF old = SetTextColor(dc, color);
    HFONT oldFont = (HFONT)SelectObject(dc, font);
    TextOutA(dc, x, y, s.c_str(), (int)s.size());
    SelectObject(dc, oldFont);
    SetTextColor(dc, old);
    SetBkMode(dc, oldBk);
}

void drawCenteredText(HDC dc, int cx, int cy, const std::string& s, COLORREF color, HFONT font) {
    SIZE sz{};
    HFONT oldFont = (HFONT)SelectObject(dc, font);
    GetTextExtentPoint32A(dc, s.c_str(), (int)s.size(), &sz);
    SelectObject(dc, oldFont);
    drawText(dc, cx - sz.cx / 2, cy - sz.cy / 2, s, color, font);
}

void drawCircle(HDC dc, int cx, int cy, int r, COLORREF color) {
    HBRUSH br = CreateSolidBrush(color);
    HBRUSH oldBr = (HBRUSH)SelectObject(dc, br);
    HPEN pen = CreatePen(PS_SOLID, 1, color);
    HPEN oldPen = (HPEN)SelectObject(dc, pen);
    Ellipse(dc, cx - r, cy - r, cx + r, cy + r);
    SelectObject(dc, oldPen);
    DeleteObject(pen);
    SelectObject(dc, oldBr);
    DeleteObject(br);
}

void alphaRect(HDC target, int x, int y, int w, int h, BYTE alpha, COLORREF color) {
    // Cria uma DIB de mesma dimens�o e preenche com a cor, depois AlphaBlend (se dispon�vel)
    BITMAPINFO bi{};
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = w;
    bi.bmiHeader.biHeight = -h;
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biCompression = BI_RGB;

    void* bits = nullptr;
    HBITMAP dib = CreateDIBSection(target, &bi, DIB_RGB_COLORS, &bits, NULL, 0);
    HDC mem = CreateCompatibleDC(target);
    HBITMAP old = (HBITMAP)SelectObject(mem, dib);

    // Preencher
    DWORD col = ((DWORD)GetBValue(color) << 16) | ((DWORD)GetGValue(color) << 8) | (DWORD)GetRValue(color);
    DWORD* p = (DWORD*)bits;
    for (int i = 0; i < w * h; ++i) p[i] = col;

    if (pAlphaBlend) {
        BLENDFUNCTION bf{ AC_SRC_OVER, 0, alpha, 0 };
        pAlphaBlend(target, x, y, w, h, mem, 0, 0, w, h, bf);
    } else {
        // fallback: desenha opaco
        BitBlt(target, x, y, w, h, mem, 0, 0, SRCCOPY);
    }

    SelectObject(mem, old);
    DeleteObject(dib);
    DeleteDC(mem);
}

void render(HDC dc) {
    // Fundo
    fillRect(dc, 0, 0, W, H, RGB(42,42,42));
    // Ch�o
    fillRect(dc, 0, groundTop, W, groundHeight, RGB(51,51,51));

    // Obst�culos (vermelho)
    for (auto& o : obstacles) {
        fillRect(dc, (int)o.x, (int)o.y, o.w, o.h, RGB(255,77,77));
    }

    // PowerUps
    for (auto& p : powerUps) {
        COLORREF c = RGB(0,255,0); // slow
        if (p.type == "highJump") c = RGB(255,255,0);
        else if (p.type == "doubleJump") c = RGB(255,0,255);
        else if (p.type == "doublePoints") c = RGB(0,255,255);
        else if (p.type == "triplePoints") c = RGB(75,174,204);
        else if (p.type == "quadruplePoints") c = RGB(52,124,191);
        else if (p.type == "quintuplePoints") c = RGB(29,75,117);
        else if (p.type == "decuplePoints") {
            // pulsante entre verde e azul
            double t = (sin(frameCount / 30.0) + 1.0) / 2.0;
            int r = 0;
            int g = (int)floor(255 * t);
            int b = (int)floor(255 * t + 128 * (1 - t));
            c = RGB(r, g, b);
        } else if (p.type == "fast") c = RGB(255,0,0);
        fillRect(dc, (int)p.x, (int)p.y, p.w, p.h, c);
    }

    // Player (c�rculo ciano)
    drawCircle(dc, (int)player.x, (int)player.y, radius, RGB(0,255,255));

    // HUD (Arial)
    std::ostringstream oss;
    drawText(dc, 12, 24 - 16, std::string("Score: ") + std::to_string(score), RGB(255,255,255), g_font16);
    drawText(dc, 12, 44 - 16, std::string("Best: ") + std::to_string(best), RGB(255,255,255), g_font16);

    if (!activePowerUp.empty()) {
        int t = std::max(0, (powerUpEndFrame - frameCount) / 60);
        drawText(dc, 12, 64 - 16, "Power-Up: " + activePowerUp + " (" + std::to_string(t) + "s)", RGB(255,255,255), g_font16);
    }

    if (debugMode) {
        drawText(dc, 12, 84 - 16, "DEBUG MODE", RGB(255,255,255), g_font16);
        drawText(dc, 12, 104 - 16, "FPS: " + std::to_string(fps), RGB(255,255,255), g_font16);

        std::ostringstream ss;
        ss.setf(std::ios::fixed); ss << std::setprecision(2) << speed;
        drawText(dc, 12, 124 - 16, "Speed: " + ss.str(), RGB(255,255,255), g_font16);

        ss.str(""); ss.clear(); ss << std::fixed << std::setprecision(2) << jumpPower;
        drawText(dc, 12, 144 - 16, "JumpPower: " + ss.str(), RGB(255,255,255), g_font16);

        ss.str(""); ss.clear(); ss << std::fixed << std::setprecision(2) << gravity;
        drawText(dc, 12, 164 - 16, "Gravity: " + ss.str(), RGB(255,255,255), g_font16);

        ss.str(""); ss.clear(); ss << std::fixed << std::setprecision(0) << multiplier;
        drawText(dc, 12, 184 - 16, "Multiplier: " + ss.str(), RGB(255,255,255), g_font16);

        drawText(dc, 12, 204 - 16, "Run Time: " + formatTime(runTime), RGB(255,255,255), g_font16);
    }

    // Overlays
    if (gameOver) {
        alphaRect(dc, 0, 0, W, H, 128, RGB(0,0,0));
        drawCenteredText(dc, W/2, H/2 - 10, "GAME OVER", RGB(255,255,255), g_font28b);
        drawCenteredText(dc, W/2, H/2 + 20, "Press SPACE or R to restart", RGB(255,255,255), g_font16);
    }
    if (paused) {
        alphaRect(dc, 0, 0, W, H, 128, RGB(0,0,0));
        drawCenteredText(dc, W/2, H/2, "PAUSE", RGB(255,255,255), g_font28b);
    }
}

// =================== Win32 Boilerplate ===================
LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_KEYDOWN: onKeyDown(wParam, lParam); break;
    case WM_KEYUP:   onKeyUp(wParam, lParam);   break;
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        // Blit do backbuffer
        BitBlt(hdc, 0, 0, W, H, g_memDC, 0, 0, SRCCOPY);
        EndPaint(hWnd, &ps);
        return 0;
    }
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

void initBackBuffer(HWND hWnd) {
    HDC hdc = GetDC(hWnd);
    g_memDC = CreateCompatibleDC(hdc);
    g_backBmp = CreateCompatibleBitmap(hdc, W, H);
    g_oldBmp = (HBITMAP)SelectObject(g_memDC, g_backBmp);
    ReleaseDC(hWnd, hdc);
}

void cleanupBackBuffer() {
    if (g_memDC) {
        SelectObject(g_memDC, g_oldBmp);
        DeleteObject(g_backBmp);
        DeleteDC(g_memDC);
        g_memDC = nullptr;
        g_backBmp = nullptr;
        g_oldBmp = nullptr;
    }
}

int APIENTRY WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int) {
    g_hInst = hInst;
    srand((unsigned)time(NULL));

    // Carregar AlphaBlend dinamicamente (msimg32 geralmente existe no Win7)
    HMODULE hMsImg = LoadLibraryA("msimg32.dll");
    if (hMsImg) {
        pAlphaBlend = (AlphaBlend_t)GetProcAddress(hMsImg, "AlphaBlend");
    }

WNDCLASSEX wc{};
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.lpszClassName = "ObstacleRunnerWin32";
    wc.hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_ICON1));
    wc.hIconSm = LoadIcon(hInst, MAKEINTRESOURCE(IDI_ICON1));
    RegisterClassEx(&wc);



    // Criar janela
    g_hWnd = CreateWindowA("ObstacleRunnerWin32", "Obstacle Runner (Win32 GDI)",
                           WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
                           CW_USEDEFAULT, CW_USEDEFAULT, W + 16, H + 39, NULL, NULL, hInst, NULL);
    ShowWindow(g_hWnd, SW_SHOW);
    UpdateWindow(g_hWnd);

    initBackBuffer(g_hWnd);

    // Fonte Arial (HUD) e Arial Bold 28 (t�tulos)
    g_font16  = CreateFontA(16,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,ANSI_CHARSET,OUT_DEFAULT_PRECIS,
                            CLIP_DEFAULT_PRECIS,ANTIALIASED_QUALITY,DEFAULT_PITCH,"Arial");
    g_font28b = CreateFontA(28,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,ANSI_CHARSET,OUT_DEFAULT_PRECIS,
                            CLIP_DEFAULT_PRECIS,ANTIALIASED_QUALITY,DEFAULT_PITCH,"Arial");

    // Estado inicial
    player = { 120.0f, (float)(groundTop - radius), 0.0f, true, 0 };
    resetGame();
    lastFrameTicks = GetTickCount();

    // Game loop com passo fixo de 60 Hz
    const double dt = 1.0 / 60.0;
    LARGE_INTEGER freq; QueryPerformanceFrequency(&freq);
    LARGE_INTEGER prev; QueryPerformanceCounter(&prev);
    double accumulator = 0.0;

    bool running = true;
    MSG msg{};
    while (running) {
        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) { running = false; break; }
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        if (!running) break;

        LARGE_INTEGER now;
        QueryPerformanceCounter(&now);
        double frameTime = (double)(now.QuadPart - prev.QuadPart) / (double)freq.QuadPart;
        if (frameTime > 0.25) frameTime = 0.25; // evita explos�es
        prev = now;

        accumulator += frameTime;

        // Atualiza em passo fixo de 60hz (como requestAnimationFrame do browser)
        while (accumulator >= dt) {
            updateLogic();
            accumulator -= dt;
        }

        // Render no backbuffer
        render(g_memDC);

        // Troca (blit) para a janela
        HDC hdc = GetDC(g_hWnd);
        BitBlt(hdc, 0, 0, W, H, g_memDC, 0, 0, SRCCOPY);
        ReleaseDC(g_hWnd, hdc);

        // pequena folga pra CPU
        Sleep(1);
    }

    // Cleanup
    DeleteObject(g_font16);
    DeleteObject(g_font28b);
    cleanupBackBuffer();

    if (hMsImg) FreeLibrary(hMsImg);
    return 0;
}
